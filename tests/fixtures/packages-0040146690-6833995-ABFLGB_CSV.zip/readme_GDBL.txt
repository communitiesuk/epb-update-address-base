                                                   
AddressBase Digital Data

This document provides instructions on how to load Ordnance Survey
digital data and provides guidance notes on matters such as the file
name referencing used and the directory structure of the DVD 
or FTP (File Transfer Protocol) method of supply. 

Readme Contents:

1. Before you begin
2. Load instructions and guidance notes
3. Testing for load completeness
4. Contacting Ordnance Survey


1. Before you begin

All Ordnance Survey Digital Data is subject to Crown Copyright. 
Your right to use the data you have received is subject to your
existing licence agreement(s). Your use of the data is limited to the 
scope of use set out in your existing licence agreement(s). 

If you have not entered into any existing Licence agreements relating
to your use of the data then you must not access or store the data. 
Where data has been supplied on media, you must promptly return the 
media to Ordnance Survey Digital Supply Team, Adanac Drive, 
Southampton, SO16 0AS.
If you have received the data via FTP, you must remove the files and 
any copies of it from your electronic storage.


2.  Load instructions and guidance notes

To use Ordnance Survey digital data you will need to load it into a 
database or use software which has a GIS/Digital Mapping capability
or Gazetteer Management System (GMS). The loading of the data will
often involve a translation process which takes the data we supply
and transforms it into a format suitable for the specific software. 
This translation may either be an integral part of the GIS/Digital
 Mapping software or an additional software module. 

The AddressBase Geography Mark-up Language (GML) and Comma Separated
Value (CSV) data is supplied in a compressed form (zip). 
Some software can access these files directly others will require it
to be uncompressed. 
To uncompress the zipped data files (.zip extension)use the unzipping
utility found on most PCs. 

The digital data is supplied as a number of chunked files that cover
your selected area. These files are named following the convention
detailed below.


AddressBase file name referencing 

The following section describes file name referencing for the 
non-geographic chunked files with a .zip file extension:

An example of a file name using the above convention is:

Product name_Supply type_CCYY-MM-DD_nnn_Format.zip

Where:

Product name - The AddressBase product name
Supply type  - FULL or COU (Change Only Update)
CCYY-MM-DD   - The date the file was generated
nnn          - The volume number of the file
Format       - This will show either gml or csv
  
                
Notes on the Supply of Ordnance Survey Digital Data on DVD

In the case of DVD Media Data Format, the directory structure and 
file naming convention used on the DVD conforms to UDF format using
the Joliet and Rock Ridge file extensions.

Extra Resources

The doc directory contains documentation relating to the 
specification of the requested data format and all of the data you 
should find in your supply.


Notes on the Supply of Ordnance Survey Digital Data via FTP

The following files will be supplied via FTP:

* Data files                 - Naming convention as 
                               explained above
* Directory.txt	             - A list of files supplied 
* readme.txt                 - This file


3. Testing for load completeness

When you have completed loading all the data, a simple check that 
this has been completed correctly is to view the full extent of the
data and visual checking that there are no obvious areas missing. 


4. Contacting Ordnance Survey

Customer Services
Adanac Drive
Southampton
SO16 0AS

Phone: 03456 050505
Email: CustomerServices@os.uk


